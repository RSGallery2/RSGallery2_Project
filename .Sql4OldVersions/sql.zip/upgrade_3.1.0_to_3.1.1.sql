ALTER TABLE `#__rsgallery2_files` MODIFY `name` varchar(255); 
ALTER TABLE `#__rsgallery2_files` MODIFY `title` varchar(255); 