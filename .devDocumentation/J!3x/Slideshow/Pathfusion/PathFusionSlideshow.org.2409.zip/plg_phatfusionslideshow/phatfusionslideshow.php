<?php
/**
* @version		$Id: phatfusionslideshow.php 2008-01-31 AmyStephen $
* @package		Joomla
* @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
*
* Thanks to phatfusion for the slideshow http://www.phatfusion.net/slideshow/
* to Mootools http://mootools.net/
* to the Joomla! devs for Joomla! :-)
* and to Rafa Jim�nez for the Spanish translation
*
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Import library dependencies
jimport('joomla.event.plugin');

/**
* Plugin that loads module positions within content
*/
class plgContentPhatfusionSlideshow extends JPlugin
{
   /**
    * Constructor
    *
    * For php4 compatability we must not use the __constructor as a constructor for
    * plugins because func_get_args ( void ) returns a copy of all passed arguments
    * NOT references.  This causes problems with cross-referencing necessary for the
    * observer design pattern.
    */
    function plgContentPhatfusionSlideshow ( &$subject, $config )
	{
		parent::__construct( $subject, $config );
	}
    /**
    * Plugin method with the same name as the event will be called automatically.
    */
    function onPrepareContent( &$row, &$params )
    {
    	// simple performance check to determine whether bot should process further
		if ( JString::strpos( $row->text, 'phatfusionslideshow' ) === false ) {
			return true;
		}
        global $mainframe;
		$document =& JFactory::getDocument();
		JHTML::_( 'behavior.mootools' );
		
		// 	Parameters
		$wait = $this->params->get( 'wait' , 3000);
		$effect = $this->params->get( 'effect', 'fade' );
		$duration = $this->params->get( 'duration', 1000 );
		$loop = $this->params->get( 'loop', 'true' );
		$thumbnails = $this->params->get( 'thumbnails', 'true' );
		$backgroundSlider = $this->params->get( 'backgroundSlider', 'true' );

		//	Add CSS		
		$document->addStyleSheet( JURI::base() . 'plugins/content/phatfusionslideshow/slideshow.css' );

		//	Add Javascript
		$document->addScript( JURI::base() .'plugins/content/phatfusionslideshow/backgroundslider.js');
		$document->addScript( JURI::base() .'plugins/content/phatfusionslideshow/slideshow.js');
	
		$js = "";
		$js = "
		window.addEvent('domready',function(){
		var obj = {
			wait: " . $wait . "," . " 
			effect: '" . $effect . "'," . " 
			duration: " . $duration . "," . "
			loop: " . $loop . "," . " 
			thumbnails: " . $thumbnails . "," . " 
			backgroundSlider: " . $backgroundSlider . "," . " 
			onClick: '' 
		}
		show = new SlideShow('slideshowContainer','slideshowThumbnail',obj);
		show.play();
		});";
		$document->addScriptDeclaration( $js );
		$firsttime = true;
			
 		// Find all Slideshows
 		$working = "";
 		$replacethis = "";
 		$withthis = "";
 		$regex = '/{phatfusionslideshow\s*.*?}/i';

 		// find all instances of plugin and put in $matches
		preg_match_all( $regex, $row->text, $matches );
		
	 	$count = count( $matches[0] );
	 	for ( $i=0; $i < $count; $i++ ) {
 		
			$replacethis = $matches[0][$i];
			$working = $replacethis;
			$working = str_replace( '{phatfusionslideshow', '', $working );
			$working = str_replace( '}', '', $working );
 			$working = trim($working);

			$withthis = '';
			if ($firsttime == true) {
				$withthis = '<div id="slideshowContainer" class="slideshowContainer"></div>';
				$withthis .= '<div id="thumbnails' . $i . '">';			
			}
			$firsttime = false;
			
			$countimagesets = 0;	
			$imagesets = explode(";",$working);
			$countimagesets = count( $imagesets );

	 		for ( $j=0; $j < $countimagesets; $j++ ) {
				$thumbnail = '';
				$imagefile = '';
				$singleimage = explode(",",$imagesets[$j]);
				$imagefile = trim($singleimage[0]);
				$thumbnail = trim($singleimage[1]);
				$withthis .= '<a href="' . $imagefile . '" class="slideshowThumbnail">';
				$withthis .= '<img src="'. $thumbnail . '" border="0" /></a>';
			}
	 		$withthis .= '<p><a href="#" onclick="show.play(); return false;">Play</a> | <a href="#" onclick="show.stop(); return false;">Stop</a> | <a href="#" onclick="show.next(); return false;">Next</a> | <a href="#" onclick="show.previous(); return false;">Previous</a></p></div>';
			$row->text = str_replace( $replacethis, $withthis, $row->text );			
 		}
		return true;
	}
}